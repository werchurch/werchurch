<?php
date_default_timezone_set("Asia/Hong_Kong");
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

/* todo....
-  receiving message works badly, some messages missed, and no bubble
   Android unable to click to view message sometimes
-  press notification after the message is read, it double shows in msgDetails, but will disappear when leave page
-  iPhone cannot video  https://stackoverflow.com/questions/36318185/how-can-i-allow-a-cordova-6-1-app-to-embed-an-iframe-in-ios-from-a-website/36440562#36440562
-  iPhone load very slow
*/

// The best way to load external JavaScript
// https://humanwhocodes.com/blog/2009/07/28/the-best-way-to-load-external-javascript/

// javascript Encoding and Escape
// http://xahlee.info/js/js_encodeURI.html

/*  PHP functions....
    php_strip_whitespace    https://www.w3schools.com/php/func_misc_php_strip_whitespace.asp
    sys_getloadavg          https://www.w3schools.com/php/func_misc_sys_getloadavg.asp
    time_nanosleep          https://www.w3schools.com/php/func_misc_time_nanosleep.asp
    time_sleep_until        https://www.w3schools.com/php/func_misc_time_sleep_until.asp
    usleep                  https://www.w3schools.com/php/func_misc_usleep.asp
    eval                    https://www.w3schools.com/php/func_misc_eval.asp
*/

/*
    var x = "我第一傳波佢就斷線";
    
        x.match(/.{1,3}/g);
        ==> Array(3) ["我第一", "傳波佢", "就斷線"]
        
        x.match(/.{1,3}/g).join("_");
        ==> "我第一_傳波佢_就斷線"
        
        x.match(/.{1,3}/g).map((val,idx,arr)=>val+idx); // this is to return, so no need to call "return"
        ==> Array(3) ["我第一0", "傳波佢1", "就斷線2"]
*/

echo '
const myApp = $$("#app");
const vHome = $$("#view-home");
const hideSplash = () =>{isMob ? setTimeout(() => {navigator.splashscreen.hide()},500) : false;setTimeout(() => {vHome.removeClass("hideV")},200)}// 200 => wait until login-screen showUp
const gotoPage = (h) => {
	app.views.current.router.navigate({
		url: "/"+h+"/",
		options:{
			animate: false,
		},
	});
}
const _allNewM = () => {     // open app by desktop icon, get newM from own server
	let r,d = "";

/*  this works....select MySQL by tags
	t = JSON.parse(localStorage.getItem("myTags"));
	Object.keys(t).forEach(function(k){     let v = t[k];
		for(let i=0,l=v.length;i<l;i++){
			d += "JSON_CONTAINS(filters,\'{\""+k+"\":\""+v[i]+"\"}\') OR ";
		}
	});     d = encodeURIComponent(d.substr(0,d.length-4));
*/
/*
	t = JSON.parse(localStorage.getItem("segments"));
	Object.keys(t).forEach(function(k){     let v = t[k];
		//for(let i=0,l=v.length;i<l;i++){
			d += "JSON_CONTAINS(included_segments,\'[\""+v+"\"]\') OR ";
		//}
	});     d = encodeURIComponent(d.substr(0,d.length-4));
*/
	//d = encodeURIComponent(localStorage.getItem("segments"));   // segments sent as string
	d = encodeURIComponent(localStorage.getItem("myTags"));     // myTags sent as string
	r = encodeURIComponent(localStorage.getItem("lastRead"));
	
	fetch("https://www.sfungapps.com/7_weRchurchappres/db/newM.php?segs="+d+"&lastRead="+r,{
		cache:"no-cache",
		method:"GET",
		mode:"cors",
		headers:{"Accept":"*/*;"}
	})
	.then((d) => {return d.json();})
	.then((j) => {          			// json object
										// https://www.w3schools.com/php/phptryit.asp?filename=tryphp_func_string_addslashes2
		if(j){
			for(let k in j){let jj = j[k];

				for(let kk in jj){      		// kk is the key name, e.g. additionalData
				
					if(kk=="additionalData"){	// data MUST be object
						let d = jj[kk];
								 j[k].additionalData = JSON.parse(d);
					}
				}
			};		setNewM(j);
		}
	})
	.catch((err) => {
		alert(err);
	});
}
/*
const printObj = (obj) => {let d = "";
	function oio(o){
		let dd = "";
		for(let kk in o){
			let vv = kk=="rawPayload" || kk=="custom" ? oio(JSON.parse(o[kk])) : o[kk];
			typeof(vv) === "object" ? (kk = "<br><strong><u>" + kk + "</u></strong><br><br>",vv = oio(vv))
									: (kk = "<br>" + kk + ":<br>",vv = vv);
			dd += kk + vv + "<br>";
		}
			return dd;
	}
	for(let k in obj){let v = obj[k];         //console.log(k,typeof(v));
		typeof(v) === "object" ? v = oio(v)
							   : JSON.stringify(v).substr(0,3) === "\"\{\\" ? v = oio(JSON.parse(v))
																			: v = v;
		//d += "<strong>Key === " + k + "</strong>" + "<br>Val === " + v + "<hr>";
		d += k + " === " + v + "<hr>";
	}
		return d;
}
*/
const getTags = () => {
	window.plugins.OneSignal.getTags(function(tags){
		let t = [Object.keys(tags)];
		localStorage.setItem("OStags",t);
	});
}
const chchLogin = () => {// church login
    new Promise(function(resolve,reject){
        resolve(app.router.navigate("/chchLogin/",{animate:false}));
        reject();
    })
    .then((r) => {
        //hideSplash();
    })
    .catch((err) => {       // One or more promises was rejected
        alert(err);
    });
}
const saveTags = (myTg) => {
	window.plugins.OneSignal.getTags(function(tags){
	    new Promise(function(resolve,reject){
			resolve(window.plugins.OneSignal.deleteTags(Object.keys(tags)));
			reject();
		})
		.then((r) => {
			setTimeout(() => {
					window.plugins.OneSignal.sendTags(myTg);
			},500);
		})
		.then((r) => {
			setTimeout(() => {
					location.reload();
			},500);
		})
		.catch((err) => {app.dialog.alert(err)});
		
		//window.plugins.OneSignal.deleteTags(Object.keys(tags));
		//window.plugins.OneSignal.sendTags(myTg);
		//location.reload();
	});
}
const initFormSend_ = (f) => {//app.preloader.show();
    /*
        https://stackoverflow.com/questions/21647928/javascript-unicode-string-to-hex
        
        "漢字".split("").reduce((hex,c)=>hex+=c.charCodeAt(0).toString(16).padStart(4,"0"),"")
        ==> "6f225b57"
        
        for non unicode
        "hi".split("").reduce((hex,c)=>hex+=c.charCodeAt(0).toString(16).padStart(2,"0"),"")
        ==> "6869"
        
        ASCII (utf-8) binary HEX string to string
        "68656c6c6f20776f726c6421".match(/.{1,2}/g).reduce((acc,char)=>acc+String.fromCharCode(parseInt(char, 16)),"")
        
        String to ASCII (utf-8) binary HEX string
        "hello world!".split("").reduce((hex,c)=>hex+=c.charCodeAt(0).toString(16).padStart(2,"0"),"")
        
        --- unicode ---
        
        String to UNICODE (utf-16) binary HEX string
        "hello world!".split("").reduce((hex,c)=>hex+=c.charCodeAt(0).toString(16).padStart(4,"0"),"")
        
        UNICODE (utf-16) binary HEX string to string
        "00680065006c006c006f00200077006f0072006c00640021".match(/.{1,4}/g).reduce((acc,char)=>acc+String.fromCharCode(parseInt(char, 16)),"")
    */
    
    /*
        PHP convert_uudecode()
        https://www.w3schools.com/php/func_string_convert_uudecode.asp
        
        PHP addslashes() *** for safety in a database query ***
        https://www.w3schools.com/php/func_string_addslashes.asp
        PHP stripslashes()
        https://www.w3schools.com/php/func_string_stripslashes.asp
        
        PHP strip_tags()
        https://www.w3schools.com/php/func_string_strip_tags.asp
        
        PHP wordwrap()  *** wrap a string into new lines when it reaches a specific length
        https://www.w3schools.com/php/func_string_wordwrap.asp
    */

    let chch = {},
        item = $$("#"+f).find(".initInput")
        tags = (g,tg) => {let all = {};
        
            for(let i=0,l=tg.length;i<l;i++){let t = {};
            
                switch(g){
        			case "fls": t["gpt"]="團契";break;
        			case "pgs": t["gpt"]="小組";break;
        			case "svs": t["gpt"]="侍奉";break;
        		}
                    t["nam"] = g;
                    t["txt"] = tg[i];
                    t["val"] = tg[i];   // not yet....how to set OneSignal tags
                    
                    console.log(t);
            }
        		    return all;
        }

    for(let i=0,l=item.length;i<l;i++){
        let itm = item[i],
             id = itm.id,
              v = itm.value.trim(),
              t = itm.nodeName;

        if(t=="INPUT"){chch[id] = v;}else{
    		switch(id){
    			case "fls":
    			case "pgs":
    			case "svs": chch[id] = tags(id,v.trim().split(","));break;
    		}
        }
	}
	    console.log(chch);
}
const saveMyChurch = (d) => {setLocal("myChurch",d)} // d is object
const initFormSend = () => {
    let chch = {},
        oTel = myCh.chTel,
        iniC = myCh.initCode,
        item = $$("#initForm").find(".initInput"),
        tags = [{"gpt":"","nam":"chchNam","val":iniC,"txt":"全部會眾"}],
        tgfn = (g,tg) => {// this to create allTags under data (object)

            for(let i=0,l=tg.length;i<l;i++){let t = {};
            
                switch(g){
        			case "fls":     t["gpt"]="團契";break;
        			case "pgs":     t["gpt"]="小組";break;
        			case "svs":     t["gpt"]="侍奉";break;
        		}
                    t["nam"] = g;
                    t["txt"] = tg[i];
                    t["val"] = tg[i];   // not yet....how to set OneSignal tags
            }
        },
        canP = (num) => {let aa = [];

            num.forEach(function(val,i){
                let o = {},
                    a = val.replace(/[●。，‧]/g,",").split(","),
                    k = apfn.properCase(a[0].trim()),               //name
                    v = a[1].trim().replace(/( |-|－|　)+/g,"");    //mobile
                    
                 o[k] = v;         aa.push(o);
            });             return aa;
        };

    for(let i=0,l=item.length;i<l;i++){
        let itm = item[i],
             id = itm.id,
              v = itm.value.trim(),
              t = itm.nodeName;

        if(t=="INPUT"){
                switch(id){
                    case "sectE":
        			case "chnamE":  v = v.replace(/ +/g,"_").replace(/_?church/gi,"");break;
                }
                   chch[id] = v;
        }else{
        		switch(id){
        			case "fls":
        			case "pgs":
        			case "svs":     tags[id] = tgfn(id,v.split(","));break;
        			case "canPush": chch[id] = canP(v.replace(/\n+/g,"\n").split(/\r?\n/));break;
        		}
        }
	};              chch.allTags = tags;
	
	app.request.get(apdm+"db/churchUpdate.php?oTel="+oTel+"&chch="+JSON.stringify(chch),function(ch){
	
    	if(ch==1){
    	        app.dialog.alert("資料已更新");
    	        $$(".dialog-buttons").on("click",(e) => location.reload());
    	        //saveMyChurch(ch);
    	}else{
    	        app.dialog.alert("<p>"+ch+"</p>請檢查輸入資料正確");    // ch.includes("Database Error")
    	}   
	       /*
	            [{"gpt":"","nam":"chchNam","val":"Taohsien","txt":"全部會眾"},{"gpt":"團契","nam":"fls","val":"joshua","txt":"約書亞"},{"gpt":"團契","nam":"fls","val":"samuel","txt":"撒母耳"},{"gpt":"團契","nam":"fls","val":"emmanuel","txt":"以馬內利"},{"gpt":"團契","nam":"fls","val":"cia","txt":"CIA"},{"gpt":"團契","nam":"fls","val":"amos","txt":"阿摩司"},{"gpt":"團契","nam":"fls","val":"jireh","txt":"以勒"},{"gpt":"小組","nam":"pgs","val":"bros","txt":"弟兄組"},{"gpt":"小組","nam":"pgs","val":"feminine","txt":"婦女組"},{"gpt":"小組","nam":"pgs","val":"missionTeam","txt":"使命小組"},{"gpt":"侍奉","nam":"svs","val":"praiseTeam","txt":"敬拜隊"},{"gpt":"侍奉","nam":"svs","val":"activityGroup","txt":"活動組"}]
	       */
    });
}
const myFormSend = (f) => {app.preloader.show();
	let    u = {},											// authority:51....authority > 50 allow to send message
		myTg = {thisApp:"weRchurch"},
		inpu = document.getElementById(f).getElementsByTagName("input");

		for(let i=0,l=inpu.length;i<l;i++){let inp = inpu[i];
			switch(inp.type){
				case "tel"		:
				case "text"		: u[inp.name] = inp.value;break;
				case "checkbox"	: inp.checked ? myTg[inp.name] = 1 : false;break;
			}
		}
		          myTg["sect"] = myCh.sectE.replace(/ /g,"_");     // myCh in app.js
		       myTg["chchNam"] = myCh.initCode;
             //myTg["chchNam"] = myCh.chnamE.replace(/ /g,"_");

            u.authority = apfn.inArrayObj(JSON.parse(myCh.canPush),$$("#mobile").val()) ? 51 : 1;

            setLocal("user",JSON.stringify(u));
			setLocal("myTags",JSON.stringify(myTg));
			localStorage.removeItem("myTagsB");
			apdv.desktop ? location.reload() : saveTags(myTg);
			//isMob ? eval(sessionStorage.getItem("toRun")) : false;
}
const setMyLogin = (mTb) => {// set personal data
	let fls = "",
		pgs = "",
		svs = "",
		tgs = allTags;						// all selectable tags of the entire church
		myT = myTags ? getLocal(mTb ? mTb : "myTags") : {};

	for(let i=1,l=tgs.length;i<l;i++){
		let t = tgs[i],
			k = t.nam + "_" + t.val,			// this becomes key in myTags
			e = (k in myT) ? " myTag" : "",
			c = "<div class=\'chip chip-outline color-pink"+e+"\' onclick=\'this.querySelector(\"input\").click\'>"+
					"<div class=\'chip-label\'>"+t.txt+"</div>"+
					"<input type=\'checkbox\' data-txt=\'"+t.txt+"\' name=\'"+k+"\' />"+
				"</div>";
							switch(t.nam){
								case "fls":	fls += c;break;
								case "pgs":	pgs += c;break;
								case "svs":	svs += c;break;
							}
	}
		$$("#my_fls").html(fls);
		$$("#my_pgs").html(pgs);
		$$("#my_svs").html(svs);   fillMyLogin();
}
const fillMyLogin = () => {
    if(user){let u = getLocal("user");
                 u.authority < 51 ? $$("#setMyChurch").remove() : false;
    
		$$("#myForm").find(".myTag").click();
		$$("#nickNam").val(u.nickNam);
		$$("#mobile").val(u.mobile);
	}
}
const setMyChurch = () => {
                            let mC = getLocal("myChurch");
    for(let k in mC){
                            let v = mC[k].replace(/_/g," ");
        if(k=="canPush"){
                $$("#"+k).val(
                    JSON.parse(v).map(e => Object.entries(e).join(",")).join("\n")
                );
        }else{
                $$("#"+k).val(v);
        }
    }
}
const appToast = (t) => {apfn.myToast(t)};
		
const   ws = (h) => {  let hp = h.substr(0,2);
			switch(hp){
				case "ht": hp = h;break;
				case "ww": hp = "http://" + h;break;
				default  : hp = "http://www." + h;
			};  return hp;
		};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//vHome.find(".page-content").append("before F7 init<br>");
// framework7						// template  https://github.com/phonegap/phonegap-template-framework7/blob/master/template_src/www/js/my-app.js
const app = new Framework7({		// Init App  https://framework7.io/docs/app.html#app-methods-properties
	id: "sfungapps.werchurch",
	root: "#app",
	theme: "ios",
	language: navigator.language,
	init: false,                  // prevent app from automatic initialization 
	initOnDeviceReady:false,        // set to true causes error (need to study)
	domCache: false,
	fastClicks: true,
	material: false,
	materialRipple: false,
	animatePages: false,
	swipeout: true,
	disableContextMenu: false,
	onAjaxStart: (xhr) => {app.preloader.show();/*app.dialog.preloader();*/},
	onAjaxComplete: (xhr) => {app.preloader.hide();/*app.dialog.close()*/},
	view:{	/*
			stackPages: true,
			pushState: true,
			*/
			iosSwipeBack: false,    // swipe back from left edge of screen back to previous page. iOS only
			animate: true,          // transitions animation between pages => .2s (default .4s or 400ms, all 76 changed in framework7.ios.min.css)
			animateWithJS: false,
			//iosDynamicNavbar: false,
			//iosSeparateDynamicNavbar: false,
			//iosAnimateNavbarBackIcon: false,
	},
	touch:{
		disableContextMenu: false,  // set to false to enable mobile menu (copy and paste) on input & textarea
		tapHold: true               // enable tap hold events
	},
	panel:{
		/*swipe: "left",	swipe direction to open panel, default false*/
	},
	dialog:{
		title: "weRchurch",	    // set default title for all dialog shortcuts			
		buttonOk: "確定",	    // change default "OK" button text
		buttonCancel: "取消",	// change default "OK" button text
	},
	sheet:{                     // sheet-modal settings
        backdrop:true,
        closeByBackdropClick:true,
    },
	data:() => {
		return{
			allTags:{},
			popup:{
					// addClass "standalonePopup" to pUp to make it standalone animation
				nv: "<div id=\"pUp\" class=\"popup\"><div class=\"view view-init popup-view\"><div class=\"page\"><div class=\"navbar\"><div class=\"navbar-inner\"><div class=\"left\"><a href=\"#\" class=\"link popup-close\"><i class=\"icon material-icons\">expand_more</i><span class=\"ios-only\">關閉</span></a></div><div class=\"title sliding\">",
				tl: "</div><div class=\"right\"><a id=\"popupSearchBar\" class=\"link icon-only searchbar-enable\" data-searchbar=\".psb\"><i class=\"icon material-icons\">youtube_searched_for</i></a></div><form data-search-container=\"\" data-search-in=\"a\" class=\"searchbar searchbar-expandable psb searchbar-init\"><div class=\"searchbar-inner\"><div class=\"searchbar-input-wrap\"><input type=\"search\" id=\"psbVal\" placeholder=\"網址\"/><i class=\"searchbar-icon\"></i><span class=\"input-clear-button\"></span></div><span id=\"psbGO\" class=\"searchbar-disable-button\">瀏覽</span></div></form></div></div><div class=\"page-content\">",
				pc: "</div></div></div></div>"
			},
			myLoader: "<div class=\"preloader-modal\" style=\"background:unset\"><div class=\"preloader\"></div></div>",
			photos: [
				  {
					html: "<iframe type=\"text/html\" src=\"https://www.youtube.com/embed/scexgBx-glQ\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" frameborder=\"0\" allowfullscreen></iframe>",
					caption: "Youtube"
				  },
				/*
				  {
					url: "img/beach.jpg",
					caption: "Amazing beach in Goa, India"
				  },
				  {
					url: "img/monkey.jpg",
					caption: "I met this monkey in Chinese mountains"
				  },
				  {
					url: "img/mountains.jpg",
					caption: "Beautiful mountains in Zhangjiajie, China"
				  }
				*/
			],
		};
	},
	methods:{
		helloWorld:(d) => {app.dialog.alert("Init Hello....\n"+d)},
		getLocal:(p) => {return JSON.parse(localStorage.getItem(p));},
		getSession:(p) => {return JSON.parse(sessionStorage.getItem(p));},
		setLocal:(p,d) => {
			localStorage.removeItem(p);
			localStorage.setItem(p,typeof d==="object" ? JSON.stringify(d) : d);
		},
		setSession:(p,d) => {
			sessionStorage.removeItem(p);
			sessionStorage.setItem(p,typeof d==="object" ? JSON.stringify(d) : d);
		},
		appendLocal:(p,d) => {d = Array.isArray(d) ? d : [d];	let m = [];
			if((p in localStorage)){
					let o = JSON.parse(localStorage.getItem(p));
							for(let i=0,l=d.length;i<l;i++){let dd = d[i];
								chkMsgID(o,dd.notificationID) ? false : m.push(dd);
							}
								m = m.concat(o);
			}else{m = d;};		setOldM(m);
		},
		appendSession:(p,d) => {d = Array.isArray(d) ? d : [d];	let m = [];
			if((p in sessionStorage)){
					let n = JSON.parse(sessionStorage.getItem(p));
							for(let i=0,l=d.length;i<l;i++){let dd = d[i];
								chkMsgID(n,dd.notificationID) ? false : m.push(dd);
							}
								m = m.concat(n);
			}else{m = d;};		setNewM(m);         //apfn.setNewM(m);
		},
		setOldM:(m) => {
			m ? localStorage.setItem("oldM",JSON.stringify(m)) : false;
			deleteBubble("#showMsg");
		},
		setNewM:(m) => {	// m is Array
			m ? sessionStorage.setItem("newM",JSON.stringify(m)) : false;
			showBubble("#showMsg",m.length);					// this in newM, received, opened events
			//showBubble("#showMsg",Object.keys(m).length);	// this in newM, received, opened events
		},
		chkMsgID:(e,n) => {	// e = existing message = array, n = id of new message = string
			for(let i=0,l=e.length;i<l;i++){
				if(e[i].notificationID==n){return 1;break;}
			}
		},
		showBubble:(o,n) => {
			n ? $$(o).find(".color-red").addClass("badge").text(n) : false;
		},
		deleteBubble:(o) => {
			$$(o).find(".color-red").removeClass("badge").empty();
		},
		deleteTags:() => {
			let k = ["chch", "chchNam", "thisApp"]; 	//console.log(k);
			window.plugins.OneSignal.deleteTags(k);
		},
		setTags:() => {
			if(!apdv.desktop){
				window.plugins.OneSignal.getTags(function(tags){        //alert(Object.keys(tags));
					window.plugins.OneSignal.deleteTags(Object.keys(tags));

				let o = JSON.parse(localStorage.getItem("myTags"));         // tags MUST be 1 layer, no array as value
						window.plugins.OneSignal.sendTags(o);               // o is object
				});
			}
		},
		checkFormInput: (f,m) => {$$(".inputErr").remove();
            let inpu = $$(f).find("input[required],textarea[required]");
            for(let i=0,l=inpu.length;i<l;i++){let inp = inpu[i];
                if(!inp.validity.valid){
                    $$("<span class=\"inputErr\" style=\"margin-left:"+m+"px\"> </span>").insertAfter($$(inp).parent());
                    return false;break;
                }
            };      return true;
        },
        chchWebCurl:() => {
            let cws = $$("#homeSwiper .chchWebCurl:not(.swiper-slide-duplicate)");
                for(let i=0,l=cws.length;i<l;i++){
                    let s = cws[i].children[0].children[0];
                    s.innerHTML = sessionStorage.getItem(s.name);
                }
        },
        backdropOn: () => {myApp.append("<div class=\"dialog-backdrop backdrop-in\"></div>")},
        backdropOff: () => {$$(".dialog-backdrop.backdrop-in").remove()},
        shareMedia: (mp3) => {window.plugins.socialsharing.share(mp3,null,null,null)},
        shareImage: (t,img) => {window.plugins.socialsharing.share(t,null,img,null);
            /*  PhoneGap social share sheet
        	    https://stackoverflow.com/questions/33992257/how-to-add-social-sharing-button-in-phonegap
        	    https://github.com/EddyVerbruggen/SocialSharing-PhoneGap-Plugin
            */
        },
        shareWithOptions: (t,f,u) => {
            // this is the complete list of currently supported params you can pass to the plugin (all optional)
            let options = {
                message: t,                       // not supported on some apps (Facebook, Instagram)
                subject: "",                      // fi. for email, the subject
                files: [f],                       // an array of filenames either locally or remotely
                url: u,                           // "https://www.website.com/foo/#bar?a=b",
                chooserTitle: ""//Pick an app"    // Android only, you can override the default share sheet title
            }
        /*
            let onSuccess = (result) => {
                alert("Share completed? " + result.completed);    // On Android apps mostly return false even while it"s true
                alert("Shared to app: " + result.app);            // On Android result.app is currently empty. On iOS it"s empty when sharing is cancelled (result.completed=false)
            }
            let onError = (msg) => {
                alert("Sharing failed with message: " + msg);
            }
        */
            window.plugins.socialsharing.shareWithOptions(options,onSuccess,onError);
        },
        mySS: (el) => {// this works....but effect not smooth enough
            let ss = app.smartSelect.create({
				el: el,
				openIn: "sheet",
				closeOnSelect: false,       // if true, clicking on the 1st option has no effect
				sheetCloseLinkText: "關閉",
				on:{
					open:(e) => {apfn.backdropOn();
					    let it = $$(".smart-select-sheet.modal-in .item-title");
					    for(let i=0,l=it.length;i<l;i++){let s = $$(it[i]);
                            s.html(s.text().replace(/\|\<\|/g,"\<div class=\"b\">").replace(/\|\>\|/g,"\<\/div\>"));
					    }
					},
					opened:(e) => {},
					close:(e) => {apfn.backdropOff();},
					closed:(e) => {},
				}
			}).open();
        },
        getChurchWebsite: (a,n) => {    // http://www.webhek.com/post/javascript-promise-api.html
            /*
            let res = () => {a.children[0].innerHTML = sessionStorage.getItem(n)},
                rej = () => {};
        
            new Promise(function(resolve,reject){
                resolve(res());reject(rej());
            })
            .then((r) => {
                setTimeout(() => {
                        apfn.mySS("a[data-bgi=\'"+n+"\']");
                },123);
            })
            .catch((err) => {       // One or more promises was rejected
                alert(err);
            });
            */
        },
        showPDF: (pdf_url,todo,t) => {// chinese.....https://www.cnblogs.com/zhanggf/p/8504317.html
                                      // show all....https://stackoverflow.com/questions/16480469/how-to-display-whole-pdf-not-only-one-page-with-pdf-js/41174415#41174415
			let __PDF_DOC,
				__CANVAS = $$("<canvas></canvas>")[0],
				__CANVAS_CTX = __CANVAS.getContext("2d");
			
			function showPage(page_no){
				// Fetch the page
				__PDF_DOC.getPage(page_no).then((page) => {
			    /*
					// As the canvas is of a fixed width we need to set the scale of the viewport accordingly
					let scale_required = __CANVAS.width / page.getViewport(1).width;
			
					// Get viewport of the page at required scale
					let viewport = page.getViewport(scale_required);
			
					// Set canvas height
					__CANVAS.height = viewport.height;
				*/
				    let scale = 2,
                        viewport = page.getViewport(scale),
					    renderContext = {canvasContext: __CANVAS_CTX,viewport: viewport};
					    
                        __CANVAS.height = viewport.height;
                        __CANVAS.width = viewport.width;
			
					// Render the page contents in the canvas
					page.render(renderContext).then((c) => {
						let src = __CANVAS.toDataURL("image/png",1);    //$$("#"+img).empty().append("<img src=\""+src+"\" \/>");
						          __CANVAS.remove();

						todo=="myPB" ? apfn[todo]([src],t) : $$("#"+todo).html("<img style=\"top:0;left:0;width:100%\" src=\""+src+"\" \/>");
					});
				});
			}
			pdfjsLib.getDocument({url:pdf_url}).then((pdf_doc) => {
				__PDF_DOC = pdf_doc;
				
				//alert(__PDF_DOC.numPages);
				
				showPage(1);        // Show the first page
			})
			.catch((err) => {
				alert(err.message);
			});
		},
		DTstring: (t) => {
			let c = new Date(t),
				y = c.getFullYear(),
				m = c.getMonth()+1,
				d = c.getDate(),
				h = c.getHours(),
				n = c.getMinutes();
			  //s = c.getSeconds();
			
			m.toString().length==1 ? m="0"+m : false;
			d.toString().length==1 ? d="0"+d : false;
			h.toString().length==1 ? h="0"+h : false;
			n.toString().length==1 ? n="0"+n : false;
		  //s.toString().lesgth==1 ? s="0"+s : false;
			
			return y + "-" + m + "-" + d + " " + h + ":" + n;   // + ":" + s;
		},
		properCase: (t) => {
		    var noCaps = ["of","a","the","and","an","am","or","nor","but","is","if","then","else","when","at","from","by","on","off","for","in","out","to","into","with","TBC"];
		    
		    return  t.replace(/\w\S*/g,function(txt,offset){
            
                        if(offset != 0 && noCaps.indexOf(txt.toLowerCase())!=-1){
            				return txt.toLowerCase();
            			}
            			    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        		    });
		},
		inArrayObj: (arr,val) => {arr = Array.isArray(arr) ? arr : [arr];
            let a = arr.map(function(v,i){
                    return Object.values(v).toString()          //.toString() is needed
            });
                    return a.includes(val);
		},
		exhref: (u) => {//u = encodeURIComponent(u);
			//window.open(u,"_blank");
			//window.location.assign(u);
			cordova.InAppBrowser.open(u,"_system","location=yes");
		},
		testPopup: (t,el,fn) => {
			let p = app.popup.create({
				//el: $$(el),  // not yet....el is the element which MUST have all the page, navbar, page-content
				content: app.data.popup.nv + t + app.data.popup.tl + $$(el)[0].innerHTML + app.data.popup.pc,
				animate: true,
				on:{
					open:(e) => {   let pp = $$(e.el);
						switch(fn){
							case "smartSel" : pp.find(".item-link").on("click",function(e){apfn.mySmartSel($$(this));});break;
							case "iFrame"   : $$("#psbGO").on("click",function(e){app.preloader.show();$$("#pUp").find("iframe").attr("src",ws($$("#psbVal").val()));});
											  $$("#popupSearchBar").css("visibility","unset");
											  break;
						}
					},
					closed:() => {app.popup.destroy();}
				}
			}).open();
		},
		testSlider: (arr) => {
			//  to dynamically generate sliders from initData.json
			//  this works....but after navigating back from other page, ".swiper-wrapper" becomes empty as beginning
			/*  
				html....
				<div id="homeSwiper" class="swiper-container demo-swiper-multiple swiper-container-horizontal">
					<div class="swiper-pagination"></div>
					<div class="swiper-wrapper"></div>
					<div class="swiper-button-prev" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="false"></div>
					<div class="swiper-button-next" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false"></div>
				</div>
			
			for(let i=0,l=arr.length;i<l;i++){let d = "",a = arr[i],s = $$(a.selector);
				if(s.length){
					a.details.map(v =>
						d += "<div class=\"swiper-slide\">"+
								"<a data-browser=\""+v.dbrowser+"\" data-href=\'"+JSON.stringify(v.dhref)+"\'>"+
									"<img src=\""+v.ic+"\" />"+
								"</a>"+
							 "</div>"
					);
						s.html(d);
				}
			};      apfn.mySwiper("#homeSwiper");
			*/
		},
		stringAjax:(u,d) => {// unable to return result....
			let a = app.request({
    				method: "GET",
    				url: apdm + u + ".php",
    				cache: false,
    				//crossDomain: true,
    				//dataType: "json",     // data = JSON.stringify(data);
    				data: "aD="+d,
    				beforeSend: (xhr) => {},
    				error: (xhr) => {console.log(xhr)},
    				success: (result) => {r=result}
    			}); return r;   //a.requestParameters.data;
		},
		mySwiper: (el) => { // http://idangero.us/swiper/api/
			let s = app.swiper.create(el,{
				direction: "horizontal",
				autoplay: false,
				effect: "slide",
				parallax: false,
				autoHeight: false,
				setWrapperSize: true,
				allowTouchMove: true,
				slidesPerView: 2,
				speed: 77,
				loop: true,
				spaceBetween: 10,
				centeredSlides: false,
				navigation: {
					nextEl: ".swiper-button-next",
					prevEl: ".swiper-button-prev",
				},
				pagination: {
					el: ".swiper-pagination",
					type: "progressbar",
				},
			}).init();
		},
		myDialog: (t,tx,c,fn) => {
			let d = app.dialog.create({
				title: t,
				text: tx,
				content: c,
				buttons: [{text: app.params.dialog.buttonCancel},{text: app.params.dialog.buttonOk}],
				closeByBackdropClick: false,
				destroyOnClose: true,
				on:{
					open:() => {},
					closed:() => {}
				},
				onClick:(d,idx) => {idx==0 ? false : eval(fn);} // idx==0 means cancel
			}).open();
		},
		initChurch: (c) => {// MUST be put as app.methods....call by apfn[fn]()
            //app.router.navigate("/messages/",{animate:true});
            let hP = $$("#homePopup");
                $$("#initCode").val(c);
                hP.find(".right").html("");
                //hP.find(".right").html("<a class=\"link\" onclick=\"initFormSend()\"><i class=\"icon material-icons\">send</i></a>");
            app.popup.open(hP);
		},
		myPrompt: (t,cnt,toRun) => {
		    app.dialog.create({
                text: t,
                content: cnt,
                buttons:[{text:app.params.dialog.buttonCancel},{text:app.params.dialog.buttonOk,close:false}], // close:false....to stay dialog open after click OK
                onClick:(p,idx) => {eval(toRun)},
                on:{
                    open:() => {},
                    close:() => {},
                    dialogClose:() => {app.preloader.hide()}
                }
            }).open();
		},
		myPopup: (cn) => {
		    let el = $$("#dynamicPopup"),           // if "el" is passed in, no need to "let"
				pc = el.find(".page-content"),
				 p = app.popup.create({             // "el" MUST include full html of page, navbar, page-content
						el:el,
					  //content:el.html(),
						animate:true,
						backdrop:false,
						on:{
							open:(e) => {
								pc.html(app.data.myLoader).css("padding","54px 10px 10px 10px");     // this works better thank app.preloader
							},
							opened:(e) => {
								app.request({
									method: "GET",
									url: apdm + "external.php",
									data: "url=" + cn[0].url,
									cache: false,
									crossDomain: true,
									//dataType: "json",         // data = JSON.stringify(data);
									beforeSend: (xhr) => {},
									error: (xhr) => {console.log(xhr);},
									success: (data) => {
										pc.html("<span class=\"pageLink hide\">"+cn[0].url+"</span>" + data);
									}
								});
							},
							close:(e) => {},
							closed:(e) => {p.destroy()},
							beforeDestroy:(d) => {}
						}
					}).open();
		},
		mySmartSel: (el) => {
			let smartSel = app.smartSelect.create({
				el: el,  //".smart-select",
				openIn: "sheet",
				//url: "msgTypes/",
				closeOnSelect: true,
				on:{
					closed:(e) => {app.smartSelect.destroy();/* unable to use "this" */},
					open:(e) => {
						$$(".sheet-modal-inner").find("li").eq(0).hide();
						pInfo = $$("#pUp").find("#info");
						$$(".block").css("word-break","break-word");
					},
					close:(e) => {
						let p = $$(el).find(".item-after").text();
						if(p=="setTag" || p=="del1Tag"){
								apfn.myDialog(
									p,
									"",
									"<div class=\"dialog-input-field item-input\"><div id=\"textBoxes\" class=\"item-input-wrap\"><input id=\"ky\" class=\"dialog-input\" placeholder=\"Key\" \/><input id=\"vl\" class=\"dialog-input\" placeholder=\"Val\" style=\"border-top:0;margin:0\" \/></div></div>",
									"showPNinfo(" + p + " + \"()\")"
								);
						}else{
								p = "getNotifications";
								//p = "additionalData";
								showPNinfo(p);    // window[this.value]() => this ONLY works running in <script>, not php
						}
					}
				}
			}).open();
		},
		myToast: (e) => {   let txt = typeof e==="object" ? e.target.text : e;
			let toast = app.toast.create({
				text: txt,
				position: "top",
				closeTimeout: 5000,
				cssClass: "appToast",
				icon: "<i class=\"material-icons\">perm_device_information</i>",
				closeButton: true,
				closeButtonText: "OK",
				closeButtonColor: "white",
				destroyOnClose: true,
				on:{
					close: () => {
						// callback example....
						// app.dialog.alert("Toast closed");
					},
				}
			}).open();
		},
		myPB: (p,t) => {  // https://framework7.io/docs/photo-browser.html
			let pb = app.photoBrowser.create({
				type: "standalone",
				//theme: "dark",
				navbar: true,
				toolbar: false,
				backLinkText: "關閉",
				navbarOfText: " / ",
				swipeToClose: false,
				photos: p,      // app.data.photos, or an array, [{url:"img/mountains.jpg",caption:"mountains"}]
				swiper: {
					initialSlide: 0,
					spaceBetween: 10,
					speed: 77,
					loop: false,
					preloadImages: true,
					navigation: {
						nextEl: ".photo-browser-next",
						prevEl: ".photo-browser-prev",
					},
					zoom: {
						enabled: true,
						maxRatio: 4,
						minRatio: 1,
					},
					lazy: {
						enabled: true,
					},
				},
				on:{
					open:() => {
					    app.preloader.hide();
					    $$(".ios .photo-browser-page-light .navbar .right").append("<a class=\"toShare\" style=\"transform:scaleX(-1)\"><i class=\"icon material-icons\">reply</i></a>");
					},
					opened:(e) => {
					    t ? $$(e.el).prepend("<span class=\"selectedOption hide\">"+ t +"</span>") : false;
					},
					close:(d) => {/*pb.params.photos=[]*/},
					closed:(e) => {pb.destroy()},
					lazyImageReady:(d) => {/*console.log("lazyReady")*/},
					beforeDestroy:(d) => {/*console.log("destroy")*/}
				}
			}).open();
		},
	},
	on:{
		init:() => {//vHome.find(".page-content").append("appInit<br>");
			// https://v3.framework7.io/docs/request.html
			// If we need it in place where we do not have access to app instance or before we init the app
            // Framework7.request.setup({headers:{"Access-Control-Allow-Origin":"*"}});     // not working....
            /*
                Framework7.request.get(apdm + "initData/initData.json",function(data){
                Framework7.request.json(apdm + "initData/initData.json",function(data){
                    // get and post methods return stringified json data, json method returns json object
                    console.log(data);
                });
            */
        ///////////////////////////////////////////////////////////////////////////////////////////////////
            /* own functions */
        try{
        	//$$("#view-home .page-content").append("functions in try..."+"<br>");
        	// no view-init in <div>

        	// this is how to router a specified page to a div
        
        	// get all routes
        	// console.dir(routes);
        
        	// all device params
        	// $$(".msgTypesSearch").css("padding","10px").html(JSON.stringify(app.device).replace(/\,\"/g,"\,\<br\>\""));
        
        	// let x = apdm + "sms.png";
        	// $$(".msgTypesSearch").css({"background":"url("+x+") no-repeat center"});
        
        
        	/* this ajax works....but fetch seems a little bit faster
        	let xhr = app.request({
        		method: "get",
        		url: apdm + "initData/initData.json",
        		cache: false,
        		crossDomain: true,
        		//dataType: "json",     // data = JSON.stringify(data);
        		data: "",
        		beforeSend: (xhr) => {},
        		error: (xhr) => {console.log(xhr);},
        		success: (data) => {
        			//localStorage.setItem("initData",data);
        			console.log(data);
        		}
        	});
        	*/
        
        
        	/* this works when loaded, but weird
        	$$("#view-home").find(".page-content").eq(0).on("scroll",(e) => {
        	console.log(e);
        	});
        	*/
        
        	/* this can get swiper, but touchMove & touchStart act weird
        	let swiper = app.swiper.get("#homeSwiper");
        	swiper
        	.on("touchStart",(e) => {   // case-sensitive
        		return false;
        	})
        	.on("touchMove",(e) => {    // case-sensitive
        		return false;
        	});
        	*/
        
        /*	
        document.getElementById("homeSwiper").outerHTML = "<div id=\"homeSwiper\" class=\"swiper-container demo-swiper-multiple swiper-container-horizontal\" data-effect=\"slide\" data-speed=\"77\" data-allow-touch-move=\"true\" data-space-between=\"0\" data-slides-per-view=\"2\" data-loop=\"true\" data-navigation=\"{&quot;nextEl&quot;: &quot;.swiper-button-next&quot;, &quot;prevEl&quot;: &quot;.swiper-button-prev&quot;}\" data-pagination=\"{&quot;el&quot;: &quot;.swiper-pagination&quot;,&quot;type&quot;: &quot;bullets&quot;}\"><div class=\"swiper-pagination\"></div><div class=\"swiper-wrapper\"><div class=\"swiper-slide\"><a class=\"item-link\" style=\"background-image:url(img/worship_pdf_pw.png)\" data-bgi=\"worship_pdf_pw\" data-open-in=\"popover\"><select name=\"worship_pdf_pw\" class=\"input-with-value\"></select></a></div><div class=\"swiper-slide\"><a style=\"background-image:url(img/worshipU.png)\" data-bgi=\"worshipU\"></a></div><div class=\"swiper-slide\"><a class=\"item-link\" style=\"background-image:url(img/speechpw.png)\" data-bgi=\"speechpw\" data-open-in=\"popover\"><select name=\"speechpw\" class=\"input-with-value speechpw\"></select></a></div><div class=\"swiper-slide\"><a style=\"background-image:url(img/newU.png)\" data-bgi=\"newU\"></a></div><div class=\"swiper-slide\"><a style=\"background-image:url(img/yearPlanU.png)\" data-bgi=\"yearPlanU\"></a></div><div class=\"swiper-slide\"><a style=\"background-image:url(img/weatherU.png)\" data-bgi=\"weatherU\"></a></div><!--<div class=\"swiper-slide\"><a><img src=\"img/worship_pdf_pw.png\" /></a></div><div class=\"swiper-slide\"><a><img src=\"img/worshipU.png\" /></a></div><div class=\"swiper-slide\"><a><img src=\"img/speechpw.png\" /></a></div><div class=\"swiper-slide\"><a><img src=\"img/newU.png\" /></a></div></div><div class=\"swiper-button-prev\" tabindex=\"0\" role=\"button\" aria-label=\"Previous slide\" aria-disabled=\"false\"></div><div class=\"swiper-button-next\" tabindex=\"0\" role=\"button\" aria-label=\"Next slide\" aria-disabled=\"false\"></div></div>";
        
        var mySwiper = new Swiper("#homeSwiper",{
            speed: 400,
            slidesPerView: 2,
            spaceBetween: 22,
            navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
        });
        
        mySwiper.init();
        */
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        myApp
        	//.on("taphold",function(){app.dialog.alert("Tap-hold fired!")})
        	.on("click","a.external",function(e){e.preventDefault();            // external => open ahref in _blank
        		try{
        			let  a = $$(this),
        				 h = a.prop("href"),
        				dh = a.data("href");
        				
        				 h ? apfn.exhref(h) : false;        //window.open(h,"_blank") : false;
        				dh ? apfn.exhref(dh): false;         //window.open(dh,"_blank") : false;
        				//dh ? cordova.InAppBrowser.open(dh,"_blank","location=yes") : false;
        		}
        		catch(err){alert(err)}
        			//window.open(h,"_blank") : false;
        	})
        	.on("click","#homeSheet.modal-in .page-content.list li",function(e){// for open-in sheet, this trigger once
        	    let li = $$(this),
        	        tt = li.find(".item-title").text(),     // get text asap, or it may return undefined
        	        ss = li.find(".item-subtitle").text(),  // for pdf, this is hidden
        	        ff = $$("#hSicon").data("bgi");
        
                $$(".backdrop-in").click();                 // close sheet modal
                app.preloader.show();
        
                setTimeout(() => {
                        if(ff=="worship_pdf_pw"){
                            app.preloader.hide();
                            apfn.exhref(chdm + ss);
                	    }
                	    if(ff=="speechpw"){
                    		let d = tt.substr(2,8).replace(/-/g,""),
                    		    f = chdm + "shared_file/Speech/" + d + ".mp3",
                    		    //p = [{html:"<video controls=\"\" autoplay=\"0\" style=\"\"><source src=\""+f+"\"></video>",caption:tt+"<br>"+ss}];
                    		    p = [{html:"<iframe src=\""+f+"\" allow=\"fullscreen\" frameborder=0></iframe>",caption:tt+"<br>"+ss}];
                
                    		apfn.myPB(p);
                	    }
                	    if(ff=="services_pdf"){
                	        apfn.showPDF(chdm + ss,"myPB",tt);
                	        //apfn.showPDF("../../7_weRchurchappres/2019年10月份崇拜事奉人員.pdf","myPB");  // for desktop testing
                	    }
                },300);
        	})
        	.on("click","#homeSwiper .swiper-slide.chchWebCurl > a",function(e){// chchWebCurl only
        		let a = $$(this),
        		    b = a.data("bgi"),
        		    s = $$("#homeSheet"),
        		    i = $$("#hSicon"),
        		    u = s.find(".media-list ul");
                        i.prop("src","img/"+b+".png").data("bgi",b);    // sheet modal icon
        		    
        	    if((b in sessionStorage)){
                        u.html(sessionStorage.getItem(b));
                        app.sheet.open(s);
        	    }else{
        		        app.request({
            				method: "GET",
            				url: apdm + "getChurchWebsite.php",
            				data: "ff=" + b,
            				cache: false,
            				crossDomain: true,
            				//dataType: "json",
            				beforeSend: (xhr) => {app.preloader.show();},
            				error: (xhr) => {console.log(xhr);},
            				success: (r) => {
        				        u.html(r);
            				    setSession(b,r);
            				    app.preloader.hide();
            				    app.sheet.open(s);
            				}
            			});
        	    }
        	})
        	.on("click","#homeSwiper .swiper-slide.chchWebDirect > a",function(e){// chchWebDirect only
        		let s = this.dataset.bgi,
        		    d = homeSwiper.find(d => d.ic===s),
        			b = d.dbrowser,
        			h = d.dhref;        // the array contains all url / captions....
                        apfn[b](h);     // b = function name, h = parameter
        	})
        	.on("click",".popupSmartSel",function(e){let d = e.target.dataset;apfn.testPopup(d.title,d.href,"smartSel");})
        	.on("click",".popupiFrame",function(e){// this is simulate web browser
        		let a = $$(this),
        			t = a.data("title"),
        			h = ws(a.data("href"));
        
        			function fs(u){
        				let cc,
        					tw = 980,
        					ss = appw / tw,
        					zz = tw / appw;
        					
        					if(u.indexOf("taohsien.org.hk")>-1){
        							cc = "top:0;left:0;margin:0;border:0;transform-origin:0 0;transform:scale("+ss+");width:"+(100*zz)+"vw;height:"+(100*zz)+"vh";
        					}else{
        							cc = "top:0;left:0;margin:0;border:0;width:inherit;height:inherit";
        					}
        						return cc;
        			}
        				let o = $$("<div><div style=\"width:100%;height:100%;overflow:hidden\"><iframe src=\""+ h +"\" style=\""+ fs(h) +"\"></iframe></div></div>");
        				 
        			app.preloader.show();
        			apfn.testPopup(t,o,"iFrame");
        
        			$$("iframe").on("load",function(e){let f = $$(this);
        				f[0].style.cssText = fs(f.attr("src"));
        				app.preloader.hide();
        			});
        		/*
        			this works, but can only navigate one more page and unable to go back
        			<a class="button button-corner button-big popup-open" data-title="Testing" data-href="/msgTypes/" data-popup="#homePopup">page-content</a>
        			
        			// only view can navigate, using [[data-name="homePopup"]] is to set the view name
        			// e.g. app.views.homePopup.router.navigate(h);
        			
        			app.views.current.router.navigate(
        				{
        					url: h,
        					options:{
        						animate: false,
        					},
        				}
        			);
        		*/
        	})
        	.on("change",".pCase",function(e){// force string to proper-case
        	    $$(this).val(apfn.properCase(this.value));
        	})
        	.on("click","#initFormSend",function(e){
                if(apfn.checkFormInput("#initForm",0)){
                    app.dialog.confirm("確認更新資料?",() => initFormSend());
                }
        	})
        	.on(clkEv,"#myFormSend",function(e){let f=$$(this).parents("form"),n=f.prop("id");
                if(apfn.checkFormInput("#"+n,0)){
                    switch(n){
                        case "initForm" : initFormSend(n);break;
                        case "myForm": myFormSend(n);break;
                    }
                }
        	})
        	.on("click",".chip.color-pink",function(e){// for chips select
        		let c = $$(this),
        			b = c.children("[type=\"checkbox\"]");
        
        			if(c.hasClass("chip-outline")){// this means un-tick
        					b.prop("checked",true);
        					c.removeClass("chip-outline");
        			}else{
        					b.prop("checked",false);
        					c.addClass("chip-outline");
        			}
        	})
        	.on(clkEv,"#leftP",function(e){// when open left-panel
        		setMyLogin();
        	})
        	.on(clkEv,"#setMyChurch",function(e){
        	    let f = "<form id=\"chCodeForm\"><div class=\"dialog-input-field item-input\"><div class=\"item-input-wrap\"><input class=\"dialog-input\" placeholder=\"更改登入編號\" minlength=\"11\" maxlength=\"11\" required></div></div></form>";
        	    
        	    // not yet....https://v3.framework7.io/docs/dialog.html
            /*
                $$(".dialog.modal-in").find(".dialog-input").val(111);
                app.dialog.prompt("What is your name?",function (name){
                    app.dialog.confirm("Are you sure that your name is " + name + "?", function () {
                      app.dialog.alert("Ok, your name is " + name);
                    });
                });
            */ 
    			app.dialog.create({
                    text: "",
                    content: "<form id=\'initPass\' onsubmit=\'return false\'><div class=\'dialog-input-field item-input\'><div class=\'item-input-wrap\'><input class=\'dialog-input\' placeholder=\'教會啓動碼\' maxlength=13 minlength=13 value=\'wf3034br44dbc\' required pattern=\'[0-9a-zA-Z]*\'></div></div></form>",
                    buttons:[{text:app.params.dialog.buttonCancel},{text:app.params.dialog.buttonOk,close:false}],
                    onClick:(p,idx) => {
                        let c = p.$el.find(".dialog-input").val();
						if(idx){
							if(apfn.checkFormInput("#initPass",0)){app.preloader.show();
								app.request.get(apdm+"db/initChurch.php?cT="+myCh.chTel+"&iC="+c,function(r){
									p.close();
									if(r==0){appToast("啓動碼無效")}
										else{
										    if(myCh){setMyChurch()};
										    app.popup.open($$("#homePopup"));
										}
								});
							}
						};
                    },
                    on:{
                        open:() => {},
                        close:() => {},
                        dialogClose:() => {app.preloader.hide()}
                    }
                }).open();
        	})
        	.on("click",".toShare",function(e){// to share
        	    //let el = $$(this).parents(".navbar").siblings(":last-of-type"),   // this gets the last sibling
        	    let el = $$(this).parents(".navbar").next();
        
        	    if(el.hasClass("photo-browser-captions")){
        	            let cap = el.text(),    // caption text
        	                med = el.next();    // container of the media
        	            
        	            cap ? apfn.shareMedia(cap + "\n\n" + med.find("source")[0].src) // share mp3 link....iframe
                            : apfn.shareImage(
                                    $$(".selectedOption").text(),                       // selected text from sheet modal
                                    med.find("img")[0].src                              // image source
                              );
        	    }else{
            	        apfn.shareMedia(
                            "《" + $$("font").text() + "》\n\n" +                       // webpage title
            	            $$(".pageLink").text()                                      // webpage link
                        );
                }
                    // this can share but cannot pass in text
                    // apfn.shareWithOptions($$(".selectedOption").text(),med.find("img")[0].src,null);
        	});
                //document.addEventListener("deviceready",onDeviceReady,false);  // app.initialized = true, output may cause error
                //document.addEventListener("backbutton",deviceBackButton,true);
                //document.addEventListener("offline",deviceOffline,false);
                //document.addEventListener("resume",deviceResume,false);
        /*
            //last li....for testing
        	$$("#homeTree").find("li:nth-last-child(1)").on("click",function(e){
        	    //$$("#homePopover .popover-inner").html("<video controls=\"\" autoplay=\"\" style=\"width:100%;height:50px\" name=\"media\"><source src=\"http://www.taohsien.org.hk/shared_file/Speech/190120.mp3\" type=\"audio/mpeg\"></video>");
        	    //app.popover.open($$("#homePopover"));
        	    
        	    apfn.stringAjax("db/initChurch",0);
        	});
        
        /*
        	$$("#homeTree").find("li:nth-last-child(2)").on("click",function(e){
        	    let cav = $$("<canvas></canvas>"),
        	        //url = "https://media.karousell.com/media/photos/products/2018/11/16/cause_way_bay_dance_studio_rental_wedfri_only_1542351087_87cbcb4d_progressive.jpg";
        	        //url = apdm + "調班表格.pdf";
        	        //url = chdm + "shared_file/WorshipPDF/190310.pdf";   // 6 pages
        	        
        	        apfn.shareImage("hello",url);
        	        //apfn.shareMedia("2019-09-29 - 何月華宣教師 ( 謙卑為大 ~ 馬太福音十八1-11 )\n\nhttp://www.taohsien.org.hk/shared_file/Speech/190929.mp3");
        	        
        	        //apfn.shareMedia(
        	            //"http://www.taohsien.org.hk/year.php"
                    //);
        	});
        */
        	/*  smartSelect....
        		So if i get you right, to update smart select, you need to manually update its <select> options and then
        		call app.initSmartSelects(pageContainer), where pageContainer is the parent .page div of this smart select.
        		This method will update visible selected values in "item-after"
        		
        		https://muut.com/framework7#!/framework7/getting-started:smart-select-inside-a-popup
        	*/
        }
        catch(err){alert(err)}      //window.onerror = (e) => {alert(e)};
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        /* get all messages */
            //isMob ? onDeviceReady() : false;
    		//user ? isMob ? allNewM() : _allNewM() : false;
        ///////////////////////////////////////////////////////////////////////////////////////////////////
/*
	崇拜部
	宣教部
	教育部
	迎新組
	長者部
	兒童部
	青少年部
	伉儷事工
	阿摩司團契
	圖書館
	撒母耳青年團
	CIA團契(職青)
	約書亞少年團(中學生)
	以馬內利團契
	香港區會
	弟兄組
	行政辦公室
	小組
	特別聚會
	婦女組
	以勒團契
	職場事工
	兒童部、伉儷部合辦
	心水補義補計劃
	活動組
	教育部、以馬內利團契合辦
	兒童部及心水補義補計劃  合辦
	堂慶社區嘉年華會
	
	講員
	主席(早堂)
	主席(午堂)
	領詩
	司琴(早堂)
	司琴(午堂)
	音響/助手
	司庫
	司事長(早堂)
	司事長(午堂)
	司事(早堂)
	司事(午堂)
	迎新(早堂)
	迎新(午堂)
	詩歌製作
	聖餐預備　(早堂)
	聖餐預備　(午堂)
*/
			// these are all tags can be chosen in msgWrite (downloaded from server, just like initData)
		
			//localStorage.setItem("user",JSON.stringify(user));
			//localStorage.setItem("myTags",JSON.stringify(myTags));
			//localStorage.setItem("oldM",JSON.stringify(oldM));

			//for testing
			//localStorage.removeItem("user");
			
			//localStorage.removeItem("oldM");    // delete all messages
			
			/*  for Database test*/
			/*
			fetch("http://www.sfungapps.com/7_weRchurchappres/db/inc_protection.php",{cache:"no-store"})
			.then((d) => {          // extract data and convert to json format
				return d.json();       // no last comma
			})
			.then((j) => {          // json object
				$$("#view-home").find(".page-content").html(j);
			})
			.catch((err) => {
				alert(err);
			});
			*/
		},
		////////// these page events apply to all pages //////////
	    pageInit:(e) => {let pg = e.el.id;      //console.log(pg);
		},
		pageReinit:(e) => {let pg = e.el.id;    //console.log(pg);
		},
		pageMounted:(e) => {let pg = e.el.id;   //console.log(pg);
		    pg ? hideSplash() : false;
		/*
			homeSwiper = app.swiper.get("#view-home #homeSwiper",{
				autoplay: false,
				effect: "slide",
				parallax: false,
				autoHeight: false,
				setWrapperSize: true,
				allowTouchMove: false,
				slidesPerView: 2,
				speed: 150,         // default 300
				loop: false,
				spaceBetween: 10,
				centeredSlides: false,
				pagination:{
					el: ".swiper-pagination",
					type: "fraction",   // "bullets", "fraction", "progressbar" or "custom"
				},
				navigation:{
					nextEl: ".swiper-button-next",
					prevEl: ".swiper-button-prev",
				},
				//observer: true,
				//observeParents: true,
			});
			
			homeSwiper.init();
		*/
		},
		pageAfterIn:(e) => {},
	},
	routes:routes,
	vi:{},	//placementId: "pltd4o7ibb9rc653x14",
});
/*
    init manually
	var app = new Framework7({
		init: false // prevent app from automatic initialization 
	});
	
	var $$ = app.$;
	$$(document).on("pageInit",function(e){
		...
	});
	
	app.init(); // init app manually after you attached all handlers
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
app.init();

const   root = app.root,
		apda = app.data,
		appw = app.width,
		apdv = app.device,
		apfn = app.methods;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//vHome.find(".page-content").append("viewInit<br>");
app.once("viewInit",function(e){// MUST be put before app.views.create....
    if(!myCh){chchLogin()}  // 1st time ever
    else{
        app.request.get(apdm+"db/myChurch.php?cT="+myCh.chTel+"&cP="+myCh.chPass,function(ch){// check church code every time
        	if(ch==0 || ch=="false"){chchLogin()}                               // loggined but church login failed
    	    else{
    	            if(("myTagsB" in localStorage) || !user){                   // church just re-loggined
            			    setMyLogin("myTagsB");
                            app.loginScreen.open($$(".login-screen"),false);    // false....no animation
        			}else{                                                      // successfully loggined
        			        saveMyChurch(ch);
        			        let u = getLocal("user");
                                u.authority = apfn.inArrayObj(JSON.parse(JSON.parse(ch).canPush),u.mobile) ? 51 : 1;
                                setLocal("user",JSON.stringify(u));
        			}
    	    }
        });
    }
});
	const viewHome = app.views.create("#view-home",{url:"/"});
	const viewFunctions = app.views.create("#view-functions",{url:"/myFunctions/"});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
document.addEventListener("deviceready",onDeviceReady,false);
document.addEventListener("backbutton",deviceBackButton,true);
document.addEventListener("offline",offlineRetry,false);
document.addEventListener("resume",allNewM,false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this makes sure to run at login
app.once("pageInit",function(e){//console.log(e.el.id);    //this runs at myFunctions init
    //vHome.find(".page-content").append("pageInit<br>");
    isMob ? myTags ?  allNewM() : _allNewM() : false;
});
';
?>