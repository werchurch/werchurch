var routes = [
  {
    path: '/',
    url: './index.html',
    name: 'home',
	options:{transition: 'f7-cover'}
  },
  {
    path: '/about/',
    url: './pages/about.html',
    name: 'about',
	options:{transition: 'f7-cover'}
  },
  {
    path: '/chchLogin/',
    componentUrl: './pages/chchLogin.html',
	options:{transition: 'f7-cover'}
  },
  {
    path: "/myFunctions/",
    componentUrl: "./pages/myFunctions.html",
	options:{transition: 'f7-cover'}
  },
  {
    path: "/msgTypes/",
    componentUrl: "./pages/msgTypes.html",
	options:{transition: 'f7-cover'}
  },
  {
	path: "/msgDetails/",
    componentUrl: "./pages/msgDetails.html",
	options:{transition: 'f7-cover'}
	/*
		path: "/msgDetails/:user/:userId/:posts/:postId/",	if using this, href MUST contain [[:user & :posts]], or page not found
															e.g. <a href="/page-loader-component/vladimir/123/about-me/1/?start=0&end=30#top">Component Page</a>
	*/
  },
  {
	path: '/msgWrite/',
	componentUrl: './pages/msgWrite.html',
	options:{transition: 'f7-cover'}
  },
  {
	path: '/msgGallery/',
	componentUrl: './pages/msgGallery.html',
	options:{transition: 'f7-cover'}
  },
  {
    path: '(.*)',
    url: './pages/404.html',	// Default route (404 page). MUST BE THE LAST
	options:{transition: 'f7-cover'}
  },
];
